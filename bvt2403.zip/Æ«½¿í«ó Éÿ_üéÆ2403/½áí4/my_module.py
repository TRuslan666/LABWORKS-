#my_module.py
def summa(a,b):
    return a+b


