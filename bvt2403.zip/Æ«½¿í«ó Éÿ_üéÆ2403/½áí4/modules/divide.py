def divide(a,b):
    if b == 0:
        return "На ноль делить нельзя!"
    return a/b


